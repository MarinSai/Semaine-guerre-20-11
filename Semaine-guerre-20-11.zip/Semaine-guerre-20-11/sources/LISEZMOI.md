Préparer les données : `python3 preparer.py` (lit observatoire-data*.json d'un clone d'obs_russie, chemin SRC en tête du script).
Compiler : `npm install`, puis `VITE_LANGUE=fr npx vite build` (idem es, it) → dist-<langue>/index.html.
Données figées au 20 novembre 2026, 14h (124 actions). Moyenne d'octobre : périodes du 3, 10, 17 et 24 octobre.
