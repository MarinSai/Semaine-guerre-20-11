# Prépare src/data.json à partir des données publiées de l'Observatoire (dépôt obs_russie).
# Périodes de sept jours glissants se terminant le vendredi 20 novembre 2026, selon la date d'entrée dans la base.
import json, datetime as dt
SRC = '/tmp/gc/obs_russie/'
FIN = dt.date(2026, 11, 20)
CATS = ['Aéronef','Frappes de navires','Sabotage','Incendie','Renseignement','Ingérence','Actions non classifiables']
langs = {l: {e['id']: e for e in json.load(open(SRC + f))['events']} for l, f in
         [('fr','observatoire-data.json'),('es','observatoire-data-es.json'),('it','observatoire-data-it.json')]}
evs = []
for e in langs['fr'].values():
    D = dt.date.fromisoformat(e['entree']); k = (FIN - D).days // 7
    if k < 0: continue
    evs.append({'id': e['id'], 'p': 8 - k, 'cat': CATS.index(e['cat']), 'seuil': e['seuil'], 'passe': e['passe'],
                'date': e['date'], 'entree': e['entree'], 'src': (e.get('sources') or [''])[0],
                'txt': {l: {'nom': langs[l][e['id']]['nom'], 'pays': langs[l][e['id']]['pays'], 'lieu': langs[l][e['id']]['lieu'],
                            'desc': langs[l][e['id']]['desc']} for l in langs}})
evs.sort(key=lambda x: (x['p'], x['entree'], x['date'], x['id']))
debuts = [(FIN - dt.timedelta(days=7 * (8 - p) + 6)).isoformat() for p in range(9)]
json.dump({'debuts': debuts, 'fin': FIN.isoformat(), 'events': evs}, open('src/data.json', 'w'), ensure_ascii=False)
import collections
print(len(evs), collections.Counter(e['p'] for e in evs), debuts)
