import { defineConfig } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import { viteSingleFile } from 'vite-plugin-singlefile';
const L = process.env.VITE_LANGUE || 'fr';
const TITRES = { fr: 'Actions hostiles contre l’Europe, sept jours après sept jours', es: 'Acciones hostiles contra Europa, siete días tras siete días', it: 'Azioni ostili contro l’Europa, sette giorni dopo sette giorni' };
export default defineConfig({
  plugins: [svelte(), viteSingleFile(), { name: 'langue', transformIndexHtml: (h) => h.replace('lang="fr"', `lang="${L}"`).replace(/<title>.*<\/title>/, `<title>${TITRES[L]}</title>`) }],
  build: { outDir: 'dist-' + L, target: 'es2019', cssCodeSplit: false, assetsInlineLimit: 100000000 }
});
