// Textes du graphique en trois langues. La langue est choisie à la compilation (VITE_LANGUE = fr, es ou it).
const MOIS = {
  fr: ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'],
  es: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'],
  it: ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre']
};
const COURTS = {
  fr: ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'],
  es: ['ene.', 'feb.', 'mar.', 'abr.', 'may.', 'jun.', 'jul.', 'ago.', 'sep.', 'oct.', 'nov.', 'dic.'],
  it: ['gen.', 'feb.', 'mar.', 'apr.', 'mag.', 'giu.', 'lug.', 'ago.', 'set.', 'ott.', 'nov.', 'dic.']
};
const jour = (l, j) => (l === 'fr' && j === 1) ? '1er' : (l === 'it' && j === 1) ? '1º' : String(j);

export const LANGUES = {
  fr: {
    page: 'Actions hostiles contre l’Europe, sept jours après sept jours',
    titre: 'Actions hostiles visant l’Europe, par semaine',
    chapo: 'Par période de sept jours, du samedi au vendredi, selon leur date d’entrée dans la base de données de l’Observatoire de la guerre politique en Europe. Chaque hexagone est une action, classée selon son degré d’attribution à la Russie.',
    moyenne: (m) => `Moyenne d’octobre : ${m} par semaine`,
    attr: (n, t) => `${n} des ${t} actions sont attribuées à la Russie ou soupçonnées de l’être.`,
    seuils: { 'Confirmé': 'Confirmé', 'Attribué': 'Attribué', 'Suspecté': 'Suspecté', 'Non déterminé': 'Non déterminé' },
    passe: 'Fait antérieur, révélé pendant la période',
    cats: ['Aéronef', 'Frappes de navires', 'Sabotage', 'Incendie', 'Renseignement', 'Ingérence', 'Actions non classifiables'],
    periode: 'Du 14 au 20 novembre',
    compte: (n, m) => `${n} actions recensées, contre ${m} en moyenne en octobre`,
    total: 'Total',
    aide: 'Cliquez sur un hexagone pour lire le détail de l’événement.',
    aideTactile: 'Touchez un hexagone pour lire le détail de l’événement.',
    faits: 'Faits', recense: 'Recensé le', lire: 'Lire la source', fermer: 'Fermer',
    preced: 'Précédent', suivant: 'Suivant',
    source: 'Source : Groupe d’études géopolitiques (Observatoire de la guerre politique en Europe) · Graphique : Le Grand Continent',
    graphe: 'Graphique en hexagones : chaque hexagone est une action hostile recensée, rangée par catégorie et par période de sept jours. La dernière période, du 14 au 20 novembre 2026, est mise en avant.',
    decimal: ','
  },
  es: {
    page: 'Acciones hostiles contra Europa, siete días tras siete días',
    titre: 'Acciones hostiles contra Europa, por semana',
    chapo: 'Por periodo de siete días, de sábado a viernes, según su fecha de entrada en la base de datos del Observatorio de la guerra política en Europa. Cada hexágono es una acción, clasificada según su grado de atribución a Rusia.',
    moyenne: (m) => `Media de octubre: ${m} por semana`,
    attr: (n, t) => `${n} de las ${t} acciones se atribuyen a Rusia o se sospecha de ella.`,
    seuils: { 'Confirmé': 'Confirmado', 'Attribué': 'Atribuido', 'Suspecté': 'Sospechado', 'Non déterminé': 'No determinado' },
    passe: 'Hecho anterior, revelado durante el periodo',
    cats: ['Aeronave', 'Ataque contra buques', 'Sabotaje', 'Incendio', 'Inteligencia', 'Injerencia', 'Acción no clasificable'],
    periode: 'Del 14 al 20 de noviembre',
    compte: (n, m) => `${n} acciones registradas, frente a ${m} de media en octubre`,
    total: 'Total',
    aide: 'Haga clic en un hexágono para leer el detalle del suceso.',
    aideTactile: 'Toque un hexágono para leer el detalle del suceso.',
    faits: 'Hechos', recense: 'Registrado el', lire: 'Leer la fuente', fermer: 'Cerrar',
    preced: 'Anterior', suivant: 'Siguiente',
    source: 'Fuente: Groupe d’études géopolitiques (Observatorio de la guerra política en Europa) · Gráfico: El Grand Continent',
    graphe: 'Gráfico de hexágonos: cada hexágono es una acción hostil registrada, clasificada por categoría y por periodo de siete días. Se destaca el último periodo, del 14 al 20 de noviembre de 2026.',
    decimal: ','
  },
  it: {
    page: 'Azioni ostili contro l’Europa, sette giorni dopo sette giorni',
    titre: 'Azioni ostili contro l’Europa, per settimana',
    chapo: 'Per periodo di sette giorni, dal sabato al venerdì, secondo la data di inserimento nella banca dati dell’Osservatorio della guerra politica in Europa. Ogni esagono è un’azione, classificata secondo il grado di attribuzione alla Russia.',
    moyenne: (m) => `Media di ottobre: ${m} a settimana`,
    attr: (n, t) => `${n} delle ${t} azioni sono attribuite alla Russia o sospettate di esserlo.`,
    seuils: { 'Confirmé': 'Confermato', 'Attribué': 'Attribuito', 'Suspecté': 'Sospetto', 'Non déterminé': 'Non determinato' },
    passe: 'Fatto anteriore, rivelato durante il periodo',
    cats: ['Velivolo', 'Attacco contro navi', 'Sabotaggio', 'Incendio', 'Intelligence', 'Ingerenza', 'Azione non classificabile'],
    periode: 'Dal 14 al 20 novembre',
    compte: (n, m) => `${n} azioni registrate, contro una media di ${m} a ottobre`,
    total: 'Totale',
    aide: 'Cliccate su un esagono per leggere i dettagli dell’evento.',
    aideTactile: 'Toccate un esagono per leggere i dettagli dell’evento.',
    faits: 'Fatti', recense: 'Registrato il', lire: 'Leggi la fonte', fermer: 'Chiudi',
    preced: 'Precedente', suivant: 'Successivo',
    source: 'Fonte: Groupe d’études géopolitiques (Osservatorio della guerra politica in Europa) · Grafico: Il Grand Continent',
    graphe: 'Grafico a esagoni: ogni esagono è un’azione ostile registrata, classificata per categoria e per periodo di sette giorni. È evidenziato l’ultimo periodo, dal 14 al 20 novembre 2026.',
    decimal: ','
  }
};
export const LANGUE = (import.meta.env.VITE_LANGUE || 'fr');
export const T = LANGUES[LANGUE];
const iso = (s) => s.split('-').map(Number);
export const dateLongue = (s) => {
  const [a, m, j] = iso(s);
  return LANGUE === 'es' ? `${j} de ${MOIS.es[m - 1]} de ${a}` : `${jour(LANGUE, j)} ${MOIS[LANGUE][m - 1]} ${a}`;
};
export const dateCourte = (s) => { const [, m, j] = iso(s); return [jour(LANGUE, j), COURTS[LANGUE][m - 1]]; };
export const decimal = (x) => (Math.round(x * 10) / 10).toString().replace('.', T.decimal);
