<script>
  import { onMount, tick } from 'svelte';
  import D from './data.json';
  import { T, LANGUE, dateLongue, dateCourte, decimal } from './textes.js';

  /* ------------------------------------------------------------------
     Données : une colonne par période de sept jours (du samedi au vendredi,
     date d'entrée dans la base), un hexagone par action, empilés du plus
     attribué (en bas) au moins attribué (en haut).
     ------------------------------------------------------------------ */
  const SEUILS = ['Confirmé', 'Attribué', 'Suspecté', 'Non déterminé'];
  const COUL = { 'Confirmé': '#8f0f24', 'Attribué': '#dd203c', 'Suspecté': '#f0a0ab', 'Non déterminé': '#c9c9ce' };
  const NP = D.debuts.length, DER = NP - 1;
  const EV = D.events;
  const colonnes = Array.from({ length: NP }, (_, p) => EV.filter((e) => e.p === p)
    .sort((a, b) => SEUILS.indexOf(a.seuil) - SEUILS.indexOf(b.seuil) || a.cat - b.cat || a.date.localeCompare(b.date)));
  const totaux = colonnes.map((c) => c.length);
  // octobre : les quatre périodes entièrement comprises dans le mois (3, 10, 17 et 24 octobre)
  const OCT = D.debuts.map((d, p) => ({ d, p })).filter(({ d }) => {
    const fin = new Date(d + 'T12:00:00Z'); fin.setUTCDate(fin.getUTCDate() + 6);
    return d.slice(5, 7) === '10' && fin.getUTCMonth() === 9;
  }).map(({ p }) => p);
  const moyOct = OCT.reduce((s, p) => s + totaux[p], 0) / OCT.length;
  const ordre = colonnes.flat();

  const etiquette = (p) => {
    const [j, m] = dateCourte(D.debuts[p]);
    if (p !== DER) return [j, m];
    const [jf, mf] = dateCourte(D.fin);
    return [`${j}-${jf}`, mf];
  };

  /* ------------------------------------------------------------------
     Géométrie : hexagones à pointe en haut, rangs décalés (nid d'abeille)
     ------------------------------------------------------------------ */
  let W = 0;
  $: tel = W > 0 && W < 600;
  $: parRang = tel ? 2 : 3;
  $: colW = W / NP;
  $: pas = Math.min(tel ? 17 : 29, (colW - (tel ? 1 : 12)) / (parRang + 0.5));   // pas horizontal (largeur + espace)
  $: hw = pas - (tel ? 1.3 : 2.4);                                                 // largeur dessinée (plat à plat)
  $: hh = hw / 0.866;                                                              // hauteur (pointe à pointe)
  $: dy = (pas / 0.866) * 0.75;                                                    // pas vertical
  $: rangsMax = Math.ceil(Math.max(...totaux) / parRang);
  $: HAUT = tel ? 34 : 40;                                                         // place des totaux
  $: base = HAUT + (rangsMax - 1) * dy + hh / 2 + 6;                               // ligne de base
  $: H = base + (tel ? 36 : 30);
  $: hex = `M0 ${-hh / 2} L${hw / 2} ${-hh / 4} L${hw / 2} ${hh / 4} L0 ${hh / 2} L${-hw / 2} ${hh / 4} L${-hw / 2} ${-hh / 4}Z`;
  const pos = (p, i) => {
    const r = Math.floor(i / parRang), k = i % parRang;
    const larg = (parRang + 0.5) * pas;
    const x0 = p * colW + (colW - larg) / 2 + pas / 2 + (r % 2 ? pas / 2 : 0);
    return [x0 + k * pas, base - hh / 2 - 3 - r * dy];
  };
  $: hautCol = (p) => pos(p, Math.max(0, totaux[p] - 1))[1] - hh / 2;
  // ligne de la moyenne d'octobre, à la hauteur d'une colonne de 10,5 hexagones
  $: yMoy = base - hh / 2 - 3 - ((moyOct / parRang) - 0.5) * dy;

  /* ------------------------------------------------------------------
     Sélection, survol
     ------------------------------------------------------------------ */
  let choisi = null, survol = null, bulle = { x: 0, y: 0 };
  let fiche, tactile = false;
  const txt = (e) => e.txt[LANGUE];

  async function choisir(e) {
    choisi = choisi && choisi.id === e.id ? null : e;
    survol = null;
    if (choisi) {
      await tick();
      const r = fiche?.getBoundingClientRect();
      if (r && (r.bottom > innerHeight || r.top < 0)) fiche.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'nearest' });
    }
  }
  const touche = (k, e) => { if (k.key === 'Enter' || k.key === ' ') { k.preventDefault(); choisir(e); } };
  function voisin(d) {
    const i = ordre.findIndex((e) => e.id === choisi.id);
    choisi = ordre[(i + d + ordre.length) % ordre.length];
  }
  function montrer(e, p, i) {
    if (tactile) return;
    const [x, y] = pos(p, i);
    bulle = { x: Math.max(105, Math.min(W - 105, x)), y: y - hh / 2 };
    survol = e;
  }
  onMount(() => {
    tactile = matchMedia('(hover: none)').matches;
    const esc = (k) => { if (k.key === 'Escape') choisi = null; };
    addEventListener('keydown', esc);
    return () => removeEventListener('keydown', esc);
  });
</script>

<div class="bloc">
  <header class="tete">
    <h1>{T.titre}</h1>
    <p class="chapo">{T.chapo}</p>
    <p class="aide">{tactile ? T.aideTactile : T.aide}</p>
  </header>

  <ul class="cle">
    {#each SEUILS as s}
      <li><svg width="13" height="15" viewBox="-6.5 -7.5 13 15" aria-hidden="true"><path d="M0 -7.2L6.2 -3.6L6.2 3.6L0 7.2L-6.2 3.6L-6.2 -3.6Z" fill={COUL[s]} /></svg>{T.seuils[s]}</li>
    {/each}
    <li><svg width="17" height="15" viewBox="-6.5 -7.5 17 15" aria-hidden="true"><path d="M0 -7.2L6.2 -3.6L6.2 3.6L0 7.2L-6.2 3.6L-6.2 -3.6Z" fill="#c9c9ce" /><circle cx="6.5" cy="-4.5" r="2.6" fill="#141414" stroke="#fff" stroke-width="1.2" /></svg>{T.passe}</li>
    <li><svg width="22" height="10" viewBox="0 0 22 10" aria-hidden="true"><line x1="0" x2="22" y1="5" y2="5" stroke="#141414" stroke-dasharray="3 3" /></svg>{T.moyenne(decimal(moyOct))}</li>
  </ul>


  <div class="scene" bind:clientWidth={W} on:mouseleave={() => (survol = null)}>
    {#if W}
      <svg width={W} height={H} viewBox="0 0 {W} {H}" role="group" aria-label={T.graphe}>
        <!-- moyenne d'octobre -->
        <line class="moy" x1="0" x2={W} y1={yMoy} y2={yMoy} />

        {#each colonnes as col, p}
          <g class="col" class:der={p === DER} class:attenue={p !== DER && !(choisi && choisi.p === p)}>
            <text class="tot" class:grand={p === DER} x={p * colW + colW / 2} y={hautCol(p) - 7}>{totaux[p]}</text>
            {#each col as e, i (e.id)}
              {@const [x, y] = pos(p, i)}
              <g class="hx" class:actif={choisi && choisi.id === e.id} transform="translate({x} {y})"
                 role="button" tabindex="0" aria-label="{txt(e).nom}, {T.seuils[e.seuil]}, {dateLongue(e.date)}" aria-pressed={!!(choisi && choisi.id === e.id)}
                 on:click={() => choisir(e)} on:keydown={(k) => touche(k, e)} on:mouseenter={() => montrer(e, p, i)} on:focus={() => montrer(e, p, i)} on:blur={() => (survol = null)}>
                <path d={hex} fill={COUL[e.seuil]} />
                {#if e.passe}<circle cx={hw / 2 - 1} cy={-hh / 2 + 2} r={tel ? 2.2 : 2.8} class="pt" />{/if}
              </g>
            {/each}
            <text class="date" class:der={p === DER} x={p * colW + colW / 2} y={base + (tel ? 15 : 18)}>
              {#if tel}{etiquette(p)[0]}<tspan x={p * colW + colW / 2} dy="13">{etiquette(p)[1]}</tspan>{:else}{etiquette(p).join(' ')}{/if}
            </text>
          </g>
        {/each}
        <line class="base" x1="0" x2={W} y1={base} y2={base} />
        <line class="base der" x1={DER * colW + 4} x2={W - 4} y1={base} y2={base} />
      </svg>

      {#if survol}
        <div class="bulle" style="left:{bulle.x}px;top:{bulle.y}px" aria-hidden="true">
          <span class="b-date">{dateLongue(survol.date)} · {txt(survol).pays}</span>
          <span class="b-nom">{txt(survol).nom}</span>
        </div>
      {/if}
    {/if}
  </div>


  <section class="fiche" class:vide={!choisi} bind:this={fiche} aria-live="polite">
    {#if choisi}
      {@const t = txt(choisi)}
      <div class="f-haut">
        <span class="f-meta">
          <svg width="13" height="15" viewBox="-6.5 -7.5 13 15" aria-hidden="true"><path d="M0 -7.2L6.2 -3.6L6.2 3.6L0 7.2L-6.2 3.6L-6.2 -3.6Z" fill={COUL[choisi.seuil]} /></svg>
          {T.cats[choisi.cat]} · {T.seuils[choisi.seuil]} · {t.pays}
        </span>
        <span class="f-nav">
          <button on:click={() => voisin(-1)} aria-label={T.preced}>‹</button>
          <button on:click={() => voisin(1)} aria-label={T.suivant}>›</button>
          <button on:click={() => (choisi = null)} aria-label={T.fermer}>×</button>
        </span>
      </div>
      <h2>{t.nom}</h2>
      <p class="f-dates">{T.faits} : {dateLongue(choisi.date)} · {T.recense} {dateLongue(choisi.entree)}{t.lieu ? ` · ${t.lieu}` : ''}{choisi.passe ? ` · ${T.passe}` : ''}</p>
      <p class="f-desc">{t.desc}</p>
    {/if}
  </section>

  <p class="source">{T.source}</p>
</div>

<style>
  .bloc{max-width:1040px;margin:0 auto;padding:6px var(--marge) 10px;display:flex;flex-direction:column;gap:14px}
  .tete{display:flex;flex-direction:column;gap:6px}
  h1{font-family:var(--titre);font-weight:700;font-size:clamp(21px,3.3vw,28px);line-height:1.16;text-wrap:balance}
  .chapo{font-size:15px;line-height:1.4;color:var(--gris);max-width:75ch}

  .cle{list-style:none;display:flex;flex-wrap:wrap;gap:6px 18px;font-size:12.5px;line-height:1.3;color:#3b3b40}
  .cle li{display:flex;align-items:center;gap:6px}
  .cle svg{flex:none;display:block}


  .scene{position:relative;line-height:0}
  .scene svg{display:block;overflow:visible}
  .col{transition:opacity .2s}
  .col.attenue{opacity:.62}
  @media (hover:hover){ .col.attenue:hover{opacity:.8} }
  .hx{cursor:pointer;outline:none}
  .hx path{transition:transform .15s ease;transform-box:fill-box;transform-origin:center}
  @media (hover:hover){ .hx:hover path{transform:scale(1.22)} }
  .hx:focus-visible path{stroke:#1f4aa8;stroke-width:2}
  .hx.actif path{stroke:#141414;stroke-width:2;transform:scale(1.25)}
  .pt{fill:#141414;stroke:#fff;stroke-width:1.2;pointer-events:none}
  text{font-family:var(--texte)}
  .tot{font-size:13px;font-weight:600;fill:#6e6e73;text-anchor:middle;font-variant-numeric:tabular-nums;paint-order:stroke;stroke:#fff;stroke-width:4px;stroke-linejoin:round}
  .tot.grand{fill:var(--rouge)}
  .date{font-size:12px;fill:#6e6e73;text-anchor:middle}
  .date.der{fill:var(--rouge);font-weight:600}
  .base{stroke:#141414;stroke-width:1}
  .base.der{stroke:var(--rouge);stroke-width:3}
  .moy{stroke:#141414;stroke-width:1;stroke-dasharray:3 3}
  .moy-t{font-size:12px;fill:#3b3b40;paint-order:stroke;stroke:#fff;stroke-width:4px;stroke-linejoin:round}

  .bulle{position:absolute;z-index:3;transform:translate(-50%,calc(-100% - 8px));width:max-content;max-width:220px;padding:7px 9px;background:#fff;line-height:1;
         border:1px solid #d6d6d6;box-shadow:0 2px 8px rgba(0,0,0,.12);pointer-events:none;display:flex;flex-direction:column;gap:3px}
  .b-date{font-size:11.5px;color:var(--gris);line-height:1.3}
  .b-nom{font-size:13px;line-height:1.3;font-weight:500}


  .fiche{border-top:1px solid var(--filet);padding-top:12px}
  .fiche.vide{display:none}
  .aide{font-size:13px;color:var(--gris);font-style:italic}
  .f-haut{display:flex;justify-content:space-between;align-items:center;gap:12px}
  .f-meta{display:flex;align-items:center;gap:7px;font-size:12.5px;color:#3b3b40}
  .f-meta svg{flex:none}
  .f-nav{display:flex;gap:2px;flex:none}
  .f-nav button{width:32px;height:32px;border:1px solid #dcdcdc;background:#fff;font:inherit;font-size:17px;line-height:1;color:#3b3b40;cursor:pointer}
  .f-nav button:hover{border-color:#9a9a9f;color:var(--encre)}
  .fiche h2{font-family:var(--titre);font-weight:700;font-size:18px;line-height:1.25;margin:8px 0 4px;text-wrap:balance}
  .f-dates{font-size:12.5px;color:var(--gris);margin-bottom:8px}
  .f-desc{font-size:14.5px;line-height:1.5;max-width:75ch}

  button:focus-visible{outline:2px solid #1f4aa8;outline-offset:2px}
  .source{font-size:12px;line-height:1.45;color:var(--gris);border-top:1px solid var(--filet);padding-top:10px}

  @media (max-width:600px){
    .bloc{gap:12px}
    .chapo{font-size:14px}
    .cle{gap:5px 14px;font-size:12px}
    .tot{font-size:11.5px}
    .date{font-size:10.5px}
    .moy-t{font-size:11px}
    .fiche h2{font-size:17px}
    .f-desc{font-size:14px}
  }
</style>
